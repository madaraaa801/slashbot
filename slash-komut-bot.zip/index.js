require('dotenv').config();
const { Client, GatewayIntentBits } = require('discord.js');

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const kelimeListesi = [
  "güneş", "çay", "kitap", "bilgisayar", "uçak",
  "sevgi", "dostluk", "yazılım", "şehir", "okul",
  "kalem", "masa", "kedi", "köpek", "ağaç"
];

client.once('ready', () => {
  console.log(`${client.user.tag} başarıyla giriş yaptı!`);
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;

  if (interaction.commandName === 'yardım') {
    await interaction.reply({
      content:
        "**📌 Komutlar:**\n" +
        "`/yardım` - Komut listesini gösterir\n" +
        "`/sayıtut min:10 max:100` - Rastgele sayı tutar\n" +
        "`/kelimetüret` - Rastgele kelime verir",
      ephemeral: true
    });
  }

  if (interaction.commandName === 'sayıtut') {
    const min = interaction.options.getInteger('min');
    const max = interaction.options.getInteger('max');

    if (min >= max) {
      return await interaction.reply({
        content: '❌ Başlangıç sayısı, bitişten küçük olmalı!',
        ephemeral: true
      });
    }

    const sayı = Math.floor(Math.random() * (max - min + 1)) + min;
    await interaction.reply(`🎲 ${min} ile ${max} arasında tuttum: **${sayı}**`);
  }

  if (interaction.commandName === 'kelimetüret') {
    const kelime = kelimeListesi[Math.floor(Math.random() * kelimeListesi.length)];
    await interaction.reply(`📖 Rastgele kelime: **${kelime}**`);
  }
});

client.login(process.env.TOKEN);
