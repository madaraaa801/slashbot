require('dotenv').config();
const { REST, Routes, SlashCommandBuilder } = require('discord.js');

const commands = [
  new SlashCommandBuilder()
    .setName('yardım')
    .setDescription('Tüm komutları gösterir.'),

  new SlashCommandBuilder()
    .setName('sayıtut')
    .setDescription('Belirttiğin aralıkta rastgele sayı tutar.')
    .addIntegerOption(option =>
      option.setName('min')
        .setDescription('Başlangıç sayısı')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('max')
        .setDescription('Bitiş sayısı')
        .setRequired(true)),

  new SlashCommandBuilder()
    .setName('kelimetüret')
    .setDescription('Rastgele bir Türkçe kelime üretir.')
].map(command => command.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

(async () => {
  try {
    console.log('Komutlar yükleniyor...');
    await rest.put(
      Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
      { body: commands }
    );
    console.log('Komutlar başarıyla yüklendi!');
  } catch (error) {
    console.error(error);
  }
})();
